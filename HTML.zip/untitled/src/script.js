function generateTracing() {
  const input = document.getElementById('tracingInput').value;
  const output = document.getElementById('outputArea');
  output.innerHTML = '';

  for (let char of input) {
    const span = document.createElement('span');
    span.className = 'trace-char';
    span.textContent = char;
    output.appendChild(span);
  }
}
